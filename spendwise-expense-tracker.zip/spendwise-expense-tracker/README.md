# SpendWise: A Simple Expense Tracker

A frontend-only web app that helps students record daily spending, see totals by category, and stay within a monthly budget.

**Student:** James Andrei Solero
**Section:** BSIT 2A
**Course:** CC211 - Application Development and Emerging Technologies (Finals Laboratory Examination, A.Y. 2025-2026)

## Target users and objectives
- Target users: students and young adults managing a small budget.
- Objectives: record expenses quickly, show where money goes, warn when the budget is nearly used.

## Features
- Add expenses with form validation (required fields, amount range, no future dates)
- Search, filter by category, and sort the expense history
- Delete expenses with a confirmation dialog
- Automatic monthly total, category breakdown, and budget meter with warnings
- Data saved in localStorage

## Technologies
HTML5, CSS3, JavaScript (ES6), Bootstrap 5.3 (CDN), Google Fonts (Bricolage Grotesque, Source Sans 3)

## How to open
1. Download or clone the repository.
2. Open `index.html` in a browser (internet is needed for Bootstrap and fonts).
3. Set a monthly budget on the Dashboard, then add expenses on the Add expense page.

## AI tools used and their contributions
_(Fill in: which AI tool you used, and what it produced. See PROMPT_LOG.md.)_

## Testing performed and corrections made
| Issue found | Correction |
| --- | --- |
| _(example) Empty form submitted without errors_ | _(example) Added validation messages_ |

_(Replace the example row with the real issues you find while testing.)_

## Known limitations
- Frontend only: data lives in this browser and device and is lost if browser data is cleared.
- No login, export, or editing of existing expenses.

## Credits
Bootstrap, Google Fonts.
