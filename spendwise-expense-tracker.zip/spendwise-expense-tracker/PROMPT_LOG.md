# PROMPT LOG

Add one entry per prompt you use. Paste the exact prompt, and be honest in the evaluation.

## Entry 1
- **Technique or framework:** _(name the technique from class)_
- **Purpose:** _(what you wanted the AI to do)_
- **Exact prompt:**
  > _(paste the full prompt here)_
- **Result summary:** _(what the AI produced)_
- **Evaluation:** _(what was correct, what had errors, what was missing)_
- **Improvement:** _(your revised prompt or manual fix)_
